INSERT INTO `t_config` (`id`, `catid`, `name`, `value`, `tag`, `lock`, `updatetime`) VALUES (10, 1, 'yzm_switch', '1', '验证码开关(1开，0关)', 1, 1453452674);
