-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- 主机： localhost
-- 生成日期： 2021-06-21 17:18:59
-- 服务器版本： 5.6.50-log
-- PHP 版本： 7.2.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 数据库： `faka`
--

-- --------------------------------------------------------

--
-- 表的结构 `t_admin_login_log`
--

CREATE TABLE `t_admin_login_log` (
  `id` int(11) NOT NULL,
  `adminid` int(11) NOT NULL DEFAULT '0' COMMENT '管理员id',
  `ip` varchar(15) NOT NULL DEFAULT '' COMMENT '登录ip',
  `addtime` int(11) NOT NULL DEFAULT '0' COMMENT '登录时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='管理员登录日志';

-- --------------------------------------------------------

--
-- 表的结构 `t_admin_user`
--

CREATE TABLE `t_admin_user` (
  `id` int(11) NOT NULL,
  `email` varchar(55) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `secret` varchar(55) NOT NULL DEFAULT '',
  `updatetime` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- 转存表中的数据 `t_admin_user`
--

INSERT INTO `t_admin_user` (`id`, `email`, `password`, `secret`, `updatetime`) VALUES
(1, '407413685@qq.com', '76b1807fc1c914f15588520b0833fbc3', '78e055', 0);

-- --------------------------------------------------------

--
-- 表的结构 `t_config`
--

CREATE TABLE `t_config` (
  `id` int(11) NOT NULL,
  `catid` int(11) NOT NULL DEFAULT '1' COMMENT '分类ID',
  `name` varchar(32) NOT NULL DEFAULT '' COMMENT '配置名',
  `value` text NOT NULL COMMENT '配置内容',
  `tag` text NOT NULL COMMENT '备注',
  `lock` tinyint(1) NOT NULL DEFAULT '0' COMMENT '锁',
  `updatetime` int(11) NOT NULL DEFAULT '0' COMMENT '最后修改时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='基础配置';

--
-- 转存表中的数据 `t_config`
--

INSERT INTO `t_config` (`id`, `catid`, `name`, `value`, `tag`, `lock`, `updatetime`) VALUES
(1, 1, 'registerswitch', '0', '是否开放注册功能,1是开放,0是关闭', 1, 1453452674),
(2, 1, 'limitiporder', '3', '同一ip当日下单限制（针对未付款订单）,不限制请设置为0', 1, 1453452674),
(3, 1, 'limitemailorder', '3', '同一email当日下单限制（针对未付款订单）,不限制请设置为0', 1, 1453452674),
(4, 1, 'weburl', 'http://dd.aiongame.ml', '当前网站地址,用于支付站点异步返回，务必修改正确', 1, 1453452674),
(5, 1, 'adminemail', '407413685@qq.com', '管理员邮箱,用于接收邮件提醒用', 1, 1453452674),
(6, 1, 'webname', 'Game On', '当前站点名称', 1, 1453452674),
(7, 1, 'webdescription', '只是个游戏开始的地方', '当前站点描述', 1, 1453452674),
(8, 1, 'notice', '注意：购买后发现不会使用的人请单独购买一份有偿服务！虽然不推荐这么做！\n若有退款以及其他一些事宜可直接联系本人！（非本站原因一律不予退款）', '首页公告', 1, 1453452674),
(9, 1, 'ad', '&lt;image src=&quot;/res/images/pay/supportme.jpg&quot;&gt;', '购买页默认内容', 1, 1453452674),
(10, 1, 'yzmswitch', '1', '验证码开关(1开，0关)', 1, 1453452674),
(11, 1, 'orderinputtype', '2', '订单必填输入框选择: 1邮箱 2QQ', 1, 1453452674),
(13, 1, 'logo', '/res/images/logo.png', 'LOGO地址,默认：/res/images/logo.png', 1, 1453452674),
(14, 1, 'tongji', '<!--统计js-->', '统计脚本', 1, 1453452674),
(15, 1, 'mprodcutdescriptionswitch', '0', '移动端商品详情，隐藏(0)|显示(1)', 1, 1453452674),
(16, 1, 'orderprefix', 'zlkb', '订单前缀，只能是英文和数字,且长度不要超过5个字符串建议不要超过5个字符串', 1, 1453452674),
(17, 1, 'backgroundimage', 'res/images/admin/bg1.jpg', '前台背景图片地址', 1, 1453452674),
(18, 1, 'headermenucolor', 'layui-bg-black', '前台顶部菜单配色方案', 1, 1453452674),
(20, 1, 'layerad', '请严格遵守本地法律法规！勿用于非法活动！发现即通报有关部门！', '弹窗广告', 1, 1453452674),
(21, 1, 'loginswitch', '0', '登录开关', 1, 1453452674),
(22, 1, 'forgetpwdswitch', '0', '找回密码开关', 1, 1453452674),
(23, 1, 'adminyzmswitch', '1', '后台登录验证码开关', 1, 1453452674),
(24, 1, 'shortcuticon', '', 'ICO图标,格式必须是png或者ico或者gif', 1, 1453452674),
(25, 1, 'limitorderqty', '5', '单笔订单数量限制', 1, 1453452674),
(26, 1, 'discountswitch', '0', '折扣开关', 1, 1453452674),
(27, 1, 'qrserver', '/product/order/showqr/?url=', '生成二维码的服务地址,默认请填写:/product/order/showqr/?url=', 1, 1453452674),
(28, 1, 'paysubjectswitch', '0', '订单说明显示:0商品名,1订单号', 1, 1453452674),
(30, 1, 'emailswitch', '0', '发送用户邮件开关', 1, 1546063186),
(31, 1, 'emailsendtypeswitch', '1', '发送用户邮件方式筛选开关', 1, 1546063186),
(32, 1, 'querycontactswitch', '1', '查询方式(联系方式)开关', 1, 1546063186),
(33, 1, 'tpl', 'shadan', '全新的整站模版', 1, 1546063186);

-- --------------------------------------------------------

--
-- 表的结构 `t_config_cat`
--

CREATE TABLE `t_config_cat` (
  `id` int(11) NOT NULL,
  `catname` varchar(32) NOT NULL DEFAULT '' COMMENT '配置分类名',
  `catkey` varchar(32) NOT NULL DEFAULT '' COMMENT '配置分类KEY'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='基础配置分类';

--
-- 转存表中的数据 `t_config_cat`
--

INSERT INTO `t_config_cat` (`id`, `catname`, `catkey`) VALUES
(1, '基础设置', 'basic'),
(2, '其他设置', 'other');

-- --------------------------------------------------------

--
-- 表的结构 `t_email`
--

CREATE TABLE `t_email` (
  `id` int(11) NOT NULL,
  `sendmail` varchar(255) NOT NULL DEFAULT '' COMMENT '	发件人email',
  `sendname` varchar(255) NOT NULL DEFAULT '' COMMENT '发送人昵称',
  `protocol` varchar(255) NOT NULL DEFAULT 'smtp' COMMENT '邮件发送协议',
  `host` varchar(255) NOT NULL DEFAULT '' COMMENT 'SMTP发送邮件服务端',
  `port` varchar(55) NOT NULL DEFAULT '' COMMENT 'SMTP端口号',
  `mailaddress` varchar(255) NOT NULL DEFAULT '' COMMENT 'SMTP邮箱地址',
  `mailpassword` varchar(255) NOT NULL DEFAULT '' COMMENT 'SMTP邮箱密码',
  `smtp_crypto` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'SMTP加密方式 0关，1ssl,2tls',
  `isactive` tinyint(1) NOT NULL DEFAULT '1' COMMENT '0未激活 1激活',
  `isdelete` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0未删除,1已删除'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- 表的结构 `t_email_code`
--

CREATE TABLE `t_email_code` (
  `id` int(11) NOT NULL,
  `action` varchar(50) NOT NULL DEFAULT '' COMMENT '操作类型',
  `userid` int(11) NOT NULL DEFAULT '0' COMMENT '用户id',
  `email` varchar(255) NOT NULL DEFAULT '' COMMENT '邮箱',
  `code` varchar(50) NOT NULL DEFAULT '' COMMENT '内容',
  `ip` varchar(50) NOT NULL DEFAULT '' COMMENT 'IP',
  `result` text NOT NULL COMMENT '结果',
  `addtime` int(11) NOT NULL DEFAULT '0' COMMENT '添加时间',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '结果0未发送 1已发送',
  `checkedStatus` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0未校验，1已校验'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- 表的结构 `t_email_queue`
--

CREATE TABLE `t_email_queue` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL DEFAULT '' COMMENT ' 收件人',
  `subject` varchar(255) NOT NULL DEFAULT '' COMMENT '标题',
  `content` text NOT NULL COMMENT '内容',
  `addtime` int(11) NOT NULL DEFAULT '0' COMMENT '发送时间',
  `sendtime` int(11) NOT NULL DEFAULT '0' COMMENT '发送时间',
  `sendresult` text NOT NULL COMMENT '发送错误',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0,未发送 ，1已发送，-1,失败',
  `isdelete` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0未删除,1已删除'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- 表的结构 `t_help`
--

CREATE TABLE `t_help` (
  `id` int(11) NOT NULL,
  `typeid` int(11) NOT NULL DEFAULT '1' COMMENT '类型',
  `title` varchar(255) NOT NULL DEFAULT '' COMMENT '标题',
  `content` text NOT NULL COMMENT '内容',
  `isactive` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1是激活，0是不激活',
  `addtime` int(11) NOT NULL DEFAULT '0' COMMENT '添加时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- 转存表中的数据 `t_help`
--

INSERT INTO `t_help` (`id`, `typeid`, `title`, `content`, `isactive`, `addtime`) VALUES
(1, 1, '这是什么系统', '这就是一个伟大的系统', 1, 1527775425);

-- --------------------------------------------------------

--
-- 表的结构 `t_order`
--

CREATE TABLE `t_order` (
  `id` int(11) NOT NULL,
  `orderid` varchar(55) NOT NULL DEFAULT '0' COMMENT '订单号',
  `userid` int(11) NOT NULL DEFAULT '0' COMMENT '用户id',
  `email` varchar(255) NOT NULL DEFAULT '' COMMENT '邮箱',
  `qq` varchar(50) NOT NULL DEFAULT '' COMMENT 'QQ号码',
  `pid` int(11) NOT NULL DEFAULT '0' COMMENT '产品id',
  `productname` varchar(255) NOT NULL DEFAULT '' COMMENT '订单名称',
  `price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '单价',
  `number` int(11) NOT NULL DEFAULT '0' COMMENT '数量',
  `money` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '订单金额',
  `chapwd` varchar(55) NOT NULL DEFAULT '' COMMENT '查询密码',
  `ip` varchar(55) NOT NULL DEFAULT '' COMMENT 'ip',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态0待支付,1待处理,2已完成,3处理失败,-1删除',
  `addtime` int(11) NOT NULL DEFAULT '0' COMMENT '下单时间',
  `paytime` int(11) NOT NULL DEFAULT '0' COMMENT '支付时间',
  `tradeid` varchar(255) NOT NULL DEFAULT '' COMMENT '外部订单id',
  `paymethod` varchar(255) NOT NULL DEFAULT '' COMMENT '支付渠道',
  `paymoney` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '支付总金额',
  `kami` text NOT NULL COMMENT '卡密',
  `configure1` text NOT NULL COMMENT '额外配置1',
  `addons` text NOT NULL COMMENT '备注',
  `isdelete` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0未删除,1已删除'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- 表的结构 `t_payment`
--

CREATE TABLE `t_payment` (
  `id` int(11) NOT NULL,
  `payment` varchar(55) DEFAULT '' COMMENT '支付名',
  `payname` varchar(55) NOT NULL DEFAULT '' COMMENT '显示名称',
  `payimage` varchar(255) NOT NULL DEFAULT '' COMMENT '图片',
  `alias` varchar(55) NOT NULL DEFAULT '' COMMENT '别名',
  `sign_type` enum('RSA','RSA2','MD5','HMAC-SHA256') NOT NULL DEFAULT 'RSA2',
  `app_id` varchar(255) NOT NULL DEFAULT '',
  `app_secret` varchar(255) NOT NULL DEFAULT '',
  `ali_public_key` text NOT NULL COMMENT '配置1',
  `rsa_private_key` text NOT NULL COMMENT '配置2',
  `configure3` text NOT NULL COMMENT '配置3',
  `configure4` text NOT NULL COMMENT '配置4',
  `overtime` int(11) NOT NULL DEFAULT '0' COMMENT '支付超时,0是不限制',
  `active` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0未激活,1已激活'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- 转存表中的数据 `t_payment`
--

INSERT INTO `t_payment` (`id`, `payment`, `payname`, `payimage`, `alias`, `sign_type`, `app_id`, `app_secret`, `ali_public_key`, `rsa_private_key`, `configure3`, `configure4`, `overtime`, `active`) VALUES
(1, '支付宝当面付', '支付宝', '/res/images/pay/alipay.jpg', 'zfbf2f', 'RSA2', '', '', '', '', '', '', 0, 0),
(2, '码支付-支付宝扫码支付', '支付宝', '/res/images/pay/alipay.jpg', 'codepayalipay', 'RSA2', '619989', 'd6j0YiQbkv87X2534u9kYyouPuD2wtzA', '', '', '', '', 300, 0),
(3, '码支付-QQ扫码支付', '手机QQ', '/res/images/pay/qqpay.jpg', 'codepayqq', 'RSA2', '', '', '', '', '', '', 300, 0),
(4, '码支付-微信扫码支付', '微信', '/res/images/pay/weixin.jpg', 'codepaywx', 'RSA2', '', '', '', '', '', '', 300, 0),
(5, '支付宝电脑网站支付(WEB)', '支付宝', '/res/images/pay/alipay.jpg', 'zfbweb', 'RSA2', '2018********', '', '', '', '', '', 0, 0),
(6, '微信扫码支付', '微信', '/res/images/pay/weixin.jpg', 'wxf2f', 'MD5', '', '', '', '', '', '', 0, 0),
(7, '有赞接口', '微信', '/res/images/pay/yzpay.jpg', 'yzpay', 'RSA2', '', '', '', '', '', '', 0, 0),
(11, '微信H5支付', '微信', '/res/images/pay/weixin.jpg', 'wxh5', 'MD5', '', '', '', '', '', '', 0, 0),
(12, 'PAYPAL', 'PAYPAL', '/res/images/pay/paypal.jpg', 'paypal', 'RSA2', '', '', '', '', 'live', '7', 0, 0),
(13, 'V免签支付宝', '支付宝', '/res/images/pay/alipay.jpg', 'tmdpayalipay', 'MD5', '', 'aeafa881a84ddca15a0c6c92b166fad7', '', '', 'http://pp.aiongame.ml', '', 300, 0),
(14, 'V免签微信', '微信', '/res/images/pay/weixin.jpg', 'tmdpaywx', 'MD5', '', '', '', '', '', '', 300, 0),
(15, '易支付支付宝', '支付宝', '/res/images/pay/alipay.jpg', 'alpayalipay', 'MD5', '175219140', 'ff1NxfzLt6V', '', '', 'https://api.pvepay.cn/', '', 0, 1),
(16, '易支付微信', '微信支付', '/res/images/pay/weixin.jpg', 'alpaywxpay', 'MD5', '', '', '', '', '', '', 0, 0),
(17, '易支付QQ', 'QQ支付', '/res/images/pay/qqpay.jpg', 'alpayqqpay', 'MD5', '', '', '', '', '', '', 0, 0),
(18, 'Z支付宝', '支付宝', '/res/images/pay/alipay.jpg', 'zalipay', 'MD5', '', '', '', '', '', '', 0, 0),
(19, 'Z微信', '微信支付', '/res/images/pay/weixin.jpg', 'zwxpay', 'MD5', '', '', '', '', '', '', 0, 0),
(20, 'ZQQ', 'QQ支付', '/res/images/pay/qqpay.jpg', 'zqqpay', 'MD5', '', '', '', '', '', '', 0, 0),
(21, 'CoinPay', 'CoinPay', '/res/images/pay/coinpay.svg', 'coinoay', 'RSA2', '21', '22', '', '', '', '0.00', 300, 0),
(22, 'Mugglepay', 'Mugglepay', '/res/images/pay/crypto.png', 'mugglepay', 'MD5', '11', '11', '', '', '', '0.00', 300, 0);

-- --------------------------------------------------------

--
-- 表的结构 `t_products`
--

CREATE TABLE `t_products` (
  `id` int(11) NOT NULL,
  `typeid` int(11) NOT NULL DEFAULT '1' COMMENT '类型id',
  `active` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0未激活 1激活',
  `name` varchar(255) NOT NULL DEFAULT '' COMMENT '产品名',
  `password` varchar(60) NOT NULL DEFAULT '' COMMENT '密码',
  `description` text NOT NULL COMMENT '描述',
  `stockcontrol` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0不控制,1控制',
  `qty` int(11) NOT NULL DEFAULT '0' COMMENT '数量',
  `qty_virtual` int(11) NOT NULL DEFAULT '0' COMMENT '虚拟库存',
  `qty_switch` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0关,1开',
  `qty_sell` int(11) NOT NULL DEFAULT '0' COMMENT '销量',
  `price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '销售价',
  `price_ori` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '销售价',
  `auto` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0手动,1自动',
  `addons` text NOT NULL COMMENT '备注',
  `sort_num` int(11) NOT NULL DEFAULT '1' COMMENT '排序',
  `addtime` int(11) NOT NULL DEFAULT '0' COMMENT '添加时间',
  `isdelete` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0未删除,1已删除',
  `imgurl` text NOT NULL COMMENT '产品图片',
  `iszhekou` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0无折扣,1有折扣'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- 转存表中的数据 `t_products`
--

INSERT INTO `t_products` (`id`, `typeid`, `active`, `name`, `password`, `description`, `stockcontrol`, `qty`, `qty_virtual`, `qty_switch`, `qty_sell`, `price`, `price_ori`, `auto`, `addons`, `sort_num`, `addtime`, `isdelete`, `imgurl`, `iszhekou`) VALUES
(1, 1, 1, '永恒之塔【直连】测试', '', '&lt;b&gt;仅作延迟测试使用切勿拿来游戏使用&lt;img src=&quot;http://dd.aiongame.ml/res/layui/images/face/4.gif&quot; alt=&quot;[可怜]&quot;&gt;&lt;/b&gt;', 0, 0, 0, 0, 10, '4.00', '6.00', 1, '', 1, 1528962221, 0, '', 0),
(2, 2, 0, 'KR-共享-直连', '', '3-5人共享&amp;nbsp;', 1, 0, 1, 0, 1, '0.01', '0.00', 1, '', 99, 1616080487, 1, '', 0),
(3, 3, 0, 'KR-独享-直连', '', '独享', 1, 0, 1, 0, 1, '0.01', '0.00', 1, '', 99, 1616080520, 1, '', 0),
(4, 4, 0, 'JP-测试-独享', '', '独享', 1, 0, 1, 0, 1, '0.10', '0.10', 1, '', 99, 1616244164, 1, '', 0),
(5, 5, 0, 'JP-共享-直连', '', '共享', 1, 0, 1, 0, 1, '0.10', '0.10', 1, '', 99, 1616244214, 1, '', 0),
(6, 1, 1, '永恒之塔【优化】测试', '', '&lt;b&gt;优化测试切勿用于直接游戏&lt;/b&gt;', 1, 0, 0, 0, 0, '5.00', '8.00', 1, '', 99, 1616244316, 0, '', 0),
(7, 2, 0, 'KR-共享-优化', '', '共享', 1, 0, 1, 0, 1, '0.20', '0.20', 1, '', 99, 1616244360, 1, '', 0),
(8, 3, 0, 'KR-独享-优化', '', '独享', 1, 0, 1, 0, 1, '0.10', '0.10', 1, '', 99, 1616244393, 1, '', 0),
(9, 4, 0, 'JP-测试-共享', '', '&lt;u&gt;共享&lt;/u&gt;', 1, 0, 1, 0, 1, '0.10', '0.10', 1, '', 99, 1616244438, 1, '', 0),
(10, 6, 0, 'JP-独享-优化', '', '独享', 1, 0, 1, 0, 1, '0.10', '0.10', 1, '', 99, 1616244548, 1, '', 0),
(11, 5, 0, 'JP-共享-优化', '', '共享', 1, 0, 1, 0, 1, '0.10', '0.10', 1, '', 99, 1616244607, 1, '', 0),
(12, 6, 0, 'JP-独享-直连', '', '独享', 1, 0, 1, 0, 1, '0.10', '0.10', 1, '', 99, 1616244657, 1, '', 0),
(13, 9, 0, 'TW-独享-直连', '', '直连', 1, 0, 1, 0, 1, '1.00', '1.00', 1, '', 99, 1616244853, 1, '', 0),
(14, 10, 1, '私人定制渠道', '', '私人定制渠道', 0, 0, 1, 0, 1, '100.00', '0.10', 1, '', 99, 1624199395, 0, '', 0),
(15, 11, 1, '特殊定制', '', '&lt;p&gt;私人定制，可指定地区或商家进行游戏&lt;/p&gt;', 1, 0, 13, 1, 1, '200.00', '100.00', 0, '', 99, 1624199555, 0, '', 0),
(16, 11, 1, '网站代建', '', '&lt;p&gt;网站代建&amp;nbsp;&lt;/p&gt;', 1, 0, 9, 1, 1, '188.00', '100.00', 0, '', 99, 1624199719, 0, '', 0),
(17, 10, 1, '工作室定制渠道', '', '&lt;b&gt;标价并非实际价格&lt;/b&gt;', 0, 0, 1, 0, 1, '100.00', '1.00', 0, '', 99, 1624248973, 0, '', 0),
(18, 1, 1, '【有偿远程】', '', '用于远程解决连接问题，包括且不限于永恒之塔的问题', 0, 0, 1, 0, 1, '5.00', '0.10', 1, '', 0, 1624250460, 0, '', 0),
(19, 12, 1, '永恒之塔【直连】', '', '&lt;p&gt;永恒之塔-直连 可用于游戏&lt;/p&gt;', 1, 0, 1, 0, 1, '30.00', '50.00', 1, '', 99, 1624254908, 0, '', 0),
(20, 12, 1, '永恒之塔 【优化】', '', '&lt;p&gt;永恒之塔-优化&lt;/p&gt;', 1, 3, 1, 0, 1, '50.00', '80.00', 1, '', 99, 1624254993, 0, '', 0),
(21, 10, 1, '虚拟机环境搭建', '', '&lt;p&gt;&lt;br&gt;&lt;/p&gt;', 1, 0, 1, 0, 1, '0.10', '0.10', 1, '', 1, 1624257452, 0, '', 0);

-- --------------------------------------------------------

--
-- 表的结构 `t_products_card`
--

CREATE TABLE `t_products_card` (
  `id` int(11) NOT NULL,
  `pid` int(11) NOT NULL DEFAULT '0' COMMENT '商品id',
  `card` text NOT NULL COMMENT '卡密',
  `addtime` int(11) NOT NULL DEFAULT '0' COMMENT '添加时间',
  `active` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0可用 1已使用',
  `isdelete` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0未删除,1已删除'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- 转存表中的数据 `t_products_card`
--

INSERT INTO `t_products_card` (`id`, `pid`, `card`, `addtime`, `active`, `isdelete`) VALUES
(3, 20, 'vmess://eyJ2IjoiMiIsInBzIjoi6Z-p5Zu9IDExNiIsImFkZCI6IjExNi4xNjMuMTQuNTUiLCJwb3J0Ijo2MDAwMSwiaWQiOiJmYzk5ZDU5NC01Y2U5LTM0NjctYTRlZS0yMGNmOGQyY2Y1M2YiLCJhaWQiOjIsIm5ldCI6IndzIiwidHlwZSI6Im5vbmUiLCJob3N0IjoiIiwicGF0aCI6Ii92aWRlbyIsInRscyI6Im5vbmUifQ', 1624255358, 0, 0),
(4, 20, 'vmess://eyJ2IjoiMiIsInBzIjoi6Z-p5Zu9IDExNyIsImFkZCI6IjExNi4xNjMuMTQuNTUiLCJwb3J0Ijo2MDAwMiwiaWQiOiJmYzk5ZDU5NC01Y2U5LTM0NjctYTRlZS0yMGNmOGQyY2Y1M2YiLCJhaWQiOjIsIm5ldCI6IndzIiwidHlwZSI6Im5vbmUiLCJob3N0IjoiIiwicGF0aCI6Ii92aWRlbyIsInRscyI6Im5vbmUifQ', 1624255480, 0, 0),
(5, 20, 'vmess://eyJ2IjoiMiIsInBzIjoi6Z-p5Zu9IDExOCIsImFkZCI6IjExNi4xNjMuMTQuNTUiLCJwb3J0Ijo2MDAwMywiaWQiOiJmYzk5ZDU5NC01Y2U5LTM0NjctYTRlZS0yMGNmOGQyY2Y1M2YiLCJhaWQiOjIsIm5ldCI6IndzIiwidHlwZSI6Im5vbmUiLCJob3N0IjoiIiwicGF0aCI6Ii92aWRlbyIsInRscyI6Im5vbmUifQ', 1624255554, 0, 0),
(6, 18, '有偿远程服务！QQ407413685 在线时间10:00-20:00', 1624256077, 0, 0),
(7, 1, 'vmess://eyJ2IjoiMiIsInBzIjoiVVMtMDEiLCJhZGQiOiI1NC4xOTMuMjUwLjIyMyIsInBvcnQiOjMxNjI5LCJpZCI6IjVmZjQzYzA4LWY1MjEtNDBmNy1iMGYzLTZlMzFkOWU3MTAxYyIsImFpZCI6NTEsIm5ldCI6InRjcCIsInR5cGUiOiJub25lIiwiaG9zdCI6IiIsInBhdGgiOiIiLCJ0bHMiOiJub25lIn0', 1624256290, 0, 0);

-- --------------------------------------------------------

--
-- 表的结构 `t_products_pifa`
--

CREATE TABLE `t_products_pifa` (
  `id` int(11) NOT NULL,
  `pid` int(11) NOT NULL DEFAULT '0' COMMENT '商品d',
  `qty` int(11) NOT NULL DEFAULT '0' COMMENT '数量',
  `discount` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '优惠价格',
  `tag` varchar(255) NOT NULL DEFAULT '' COMMENT '简单说明',
  `addtime` int(11) NOT NULL DEFAULT '0' COMMENT '添加时间',
  `isdelete` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0未删除,1已删除'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- 表的结构 `t_products_type`
--

CREATE TABLE `t_products_type` (
  `id` int(11) NOT NULL,
  `name` varchar(55) NOT NULL DEFAULT '' COMMENT '类型命名',
  `description` varchar(255) NOT NULL DEFAULT '' COMMENT '分类描述',
  `password` varchar(60) NOT NULL DEFAULT '' COMMENT '分类密码',
  `sort_num` int(11) NOT NULL DEFAULT '1' COMMENT '排序',
  `active` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0未激活,1已激活',
  `isdelete` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0未删除,1已删除'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- 转存表中的数据 `t_products_type`
--

INSERT INTO `t_products_type` (`id`, `name`, `description`, `password`, `sort_num`, `active`, `isdelete`) VALUES
(1, '【美服】永恒之塔', '测试商品', '', 6, 1, 0),
(10, '游戏定制', '特殊服务', '', 1, 1, 0),
(11, '其他定制服务', '其他定制服务', '', 0, 1, 0),
(12, '【韩服】永恒之塔', '【韩服】永恒之塔', '', 5, 1, 0);

-- --------------------------------------------------------

--
-- 表的结构 `t_seo`
--

CREATE TABLE `t_seo` (
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- 表的结构 `t_ticket`
--

CREATE TABLE `t_ticket` (
  `id` int(11) NOT NULL,
  `userid` int(11) NOT NULL DEFAULT '0' COMMENT '用户id',
  `typeid` int(11) NOT NULL DEFAULT '1' COMMENT '类型',
  `priority` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0不重要 1重要',
  `subject` varchar(255) NOT NULL DEFAULT '' COMMENT '主题',
  `content` text NOT NULL COMMENT '内容',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0,刚创建;1,已回复;5已完结',
  `addtime` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- 表的结构 `t_user`
--

CREATE TABLE `t_user` (
  `id` int(11) NOT NULL,
  `groupid` int(11) NOT NULL DEFAULT '1' COMMENT '分组ID',
  `nickname` varchar(255) NOT NULL DEFAULT '' COMMENT '用户名',
  `password` varchar(255) NOT NULL DEFAULT '' COMMENT '密码',
  `email` varchar(255) NOT NULL DEFAULT '' COMMENT '邮箱',
  `qq` varchar(20) NOT NULL DEFAULT '' COMMENT 'qq',
  `mobilephone` varchar(15) NOT NULL DEFAULT '' COMMENT '手机',
  `money` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '余额',
  `integral` int(11) NOT NULL DEFAULT '0' COMMENT '积分',
  `tag` varchar(255) NOT NULL DEFAULT '' COMMENT '用户自己的备注',
  `createtime` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- 表的结构 `t_user_group`
--

CREATE TABLE `t_user_group` (
  `id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL DEFAULT '' COMMENT '用户组名',
  `remark` varchar(100) NOT NULL DEFAULT '' COMMENT '备注',
  `discount` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '折扣'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- 转存表中的数据 `t_user_group`
--

INSERT INTO `t_user_group` (`id`, `name`, `remark`, `discount`) VALUES
(1, '普通', '普通用户', '0.00'),
(2, 'VIP1', 'VIP1用户', '0.00'),
(3, 'VIP2', 'VIP2用户', '0.00'),
(4, 'VIP3', 'VIP3用户', '0.00');

-- --------------------------------------------------------

--
-- 表的结构 `t_user_login_logs`
--

CREATE TABLE `t_user_login_logs` (
  `id` int(11) NOT NULL,
  `userid` int(11) NOT NULL DEFAULT '0' COMMENT '用户id',
  `ip` varchar(25) NOT NULL DEFAULT '' COMMENT '登录ip',
  `addtime` int(11) NOT NULL DEFAULT '0' COMMENT '登录时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- 转储表的索引
--

--
-- 表的索引 `t_admin_login_log`
--
ALTER TABLE `t_admin_login_log`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `t_admin_user`
--
ALTER TABLE `t_admin_user`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `t_config`
--
ALTER TABLE `t_config`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `t_config_cat`
--
ALTER TABLE `t_config_cat`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `t_email`
--
ALTER TABLE `t_email`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `t_email_code`
--
ALTER TABLE `t_email_code`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `t_email_queue`
--
ALTER TABLE `t_email_queue`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `t_help`
--
ALTER TABLE `t_help`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `t_order`
--
ALTER TABLE `t_order`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `t_payment`
--
ALTER TABLE `t_payment`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `t_products`
--
ALTER TABLE `t_products`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `t_products_card`
--
ALTER TABLE `t_products_card`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `t_products_pifa`
--
ALTER TABLE `t_products_pifa`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `t_products_type`
--
ALTER TABLE `t_products_type`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `t_seo`
--
ALTER TABLE `t_seo`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `t_ticket`
--
ALTER TABLE `t_ticket`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `t_user`
--
ALTER TABLE `t_user`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `t_user_group`
--
ALTER TABLE `t_user_group`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `t_user_login_logs`
--
ALTER TABLE `t_user_login_logs`
  ADD PRIMARY KEY (`id`);

--
-- 在导出的表使用AUTO_INCREMENT
--

--
-- 使用表AUTO_INCREMENT `t_admin_login_log`
--
ALTER TABLE `t_admin_login_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- 使用表AUTO_INCREMENT `t_admin_user`
--
ALTER TABLE `t_admin_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- 使用表AUTO_INCREMENT `t_config`
--
ALTER TABLE `t_config`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- 使用表AUTO_INCREMENT `t_config_cat`
--
ALTER TABLE `t_config_cat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- 使用表AUTO_INCREMENT `t_email`
--
ALTER TABLE `t_email`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- 使用表AUTO_INCREMENT `t_email_code`
--
ALTER TABLE `t_email_code`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `t_email_queue`
--
ALTER TABLE `t_email_queue`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- 使用表AUTO_INCREMENT `t_help`
--
ALTER TABLE `t_help`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- 使用表AUTO_INCREMENT `t_order`
--
ALTER TABLE `t_order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- 使用表AUTO_INCREMENT `t_payment`
--
ALTER TABLE `t_payment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- 使用表AUTO_INCREMENT `t_products`
--
ALTER TABLE `t_products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- 使用表AUTO_INCREMENT `t_products_card`
--
ALTER TABLE `t_products_card`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- 使用表AUTO_INCREMENT `t_products_pifa`
--
ALTER TABLE `t_products_pifa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `t_products_type`
--
ALTER TABLE `t_products_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- 使用表AUTO_INCREMENT `t_seo`
--
ALTER TABLE `t_seo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `t_ticket`
--
ALTER TABLE `t_ticket`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `t_user`
--
ALTER TABLE `t_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- 使用表AUTO_INCREMENT `t_user_group`
--
ALTER TABLE `t_user_group`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- 使用表AUTO_INCREMENT `t_user_login_logs`
--
ALTER TABLE `t_user_login_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
