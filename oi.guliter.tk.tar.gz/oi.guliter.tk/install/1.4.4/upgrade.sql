DELETE FROM `t_payment` WHERE `t_payment`.`id` = 8;
DELETE FROM `t_payment` WHERE `t_payment`.`id` = 9;
DELETE FROM `t_payment` WHERE `t_payment`.`id` = 10;