<?php

namespace Pay\coinpay;

use \Pay\notify;

class coinpay
{
    private $createOrderUrl = "https://openapi.coinpay.la/trade/create";
    private $paymethod = "coinpay";

    //处理请求
    public function pay($payconfig, $params)
    {

        try {
            $fees = (double)$payconfig['configure4'];//手续费费率  比如 0.05
            if ($fees > 0.00) {
                $price_amount = (double)$params['money'] * (1.00 + $fees);// 价格 * （1 + 0.05）
            } else {
                $price_amount = (double)$params['money'];
            }

            $out_trade_no = $params['orderid'];
            $subject = $params['productname'];
            $price_amount = sprintf('%.2f', $price_amount);// 只取小数点后两位
            $key = $payconfig['app_secret'];

            $config = [
                'out_trade_no' => $out_trade_no,
                'subject' => $subject,
                'total_amount' => $price_amount,
                'timestamp' => date('Y-m-d H:i:s', time()),
                'app_id' => $payconfig['app_id'],
                'nonce_str' => self::getNonceStr(),
                'trans_currency' => "CNY",
                'notify_url' => $params['weburl'] . '/product/notify/?paymethod=' . $this->paymethod, //支付成功后回调地址,
                'return_url' => $params['weburl'] . "/query/auto/{$params['orderid']}.html" //同步地址
            ];
            $config = self::GetSign($key, $config);
            $createOrderUrl = $this->createOrderUrl;
            $coinpay_json = self::_curlPost($createOrderUrl, $config);
            $coinpay_date = json_decode($coinpay_json, true);

            if (!isset($coinpay_date['code']) && $coinpay_date['code'] !== 200) {
                return array('code' => 1002, 'msg' => $coinpay_date['error_code'], 'data' => '');
            } else {
                $JumpUrl = $coinpay_date['data']['payment_url'];
                $closetime = 600;
                $result = array('type' => 1, 'subjump' => 0, 'url' => $JumpUrl, 'paymethod' => $this->paymethod, 'payname' => $payconfig['payname'], 'overtime' => $closetime, 'money' => $price_amount);
                return array('code' => 1, 'msg' => 'success', 'data' => $result);
            }
        } catch (\Exception $e) {
            return array('code' => 1000, 'msg' => $e->getMessage(), 'data' => '');
        }
    }

    //处理返回
    public function notify($payconfig)
    {
        ini_set("error_reporting", "E_ALL & ~E_NOTICE");

        $inputString = file_get_contents('php://input', 'r');
        $_POST = json_decode($inputString, true); //convert JSON into array

        $key = $payconfig['app_secret'];
        $return_out_trade_no = $_POST['out_trade_no'];//商户订单号
        $return_total_amount = $_POST['total_amount'];
        $return_sign = $_POST['sign'];
        $order_id = $_POST['trade_no'];

        unset($_POST['sign']);
        $sign = self::GetSign($key, $_POST)['sign'];
        if ($return_sign !== $sign) { //不合法的数据 KEY密钥为你的密钥
            return 'error|Notify: auth fail';
        }
        if ($_POST['trade_status'] === 'TRADE_SUCCESS') {
            $config = array('paymethod' => $this->paymethod, 'tradeid' => $order_id, 'paymoney' => $return_total_amount, 'orderid' => $return_out_trade_no);
            $notify = new \Pay\notify();
            $data = $notify->run($config);
            if ($data['code'] > 1) {
                return 'error|Notify: ' . $data['msg'];
            } else {
                return json_encode(['status' => 200]);
            }
        } else { //合法的数据
            //业务处理
            return 'error|Notify: status illegal';
        }
    }

    /**
     * 设置签名，详见签名生成算法
     * @param $secret
     * @param $params
     * @return array
     */
    public function GetSign($secret, $params)
    {
        ksort($params);
        reset($params);
        $sign_param = implode('&', $params);
        $signature = hash_hmac('sha256', $sign_param, $secret, true);
        $params['sign'] = base64_encode($signature);
        return $params;
    }

    /**
     * 返回随机字符串
     * @param int $length
     * @return string
     */
    public static function getNonceStr($length = 32)
    {
        $chars = "abcdefghijklmnopqrstuvwxyz0123456789";
        $str = "";
        for ($i = 0; $i < $length; $i++) {
            $str .= substr($chars, mt_rand(0, strlen($chars) - 1), 1);
        }
        return $str;
    }

    private function _curlPost($url, $params)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_TIMEOUT, 300); //设置超时
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE); // https请求 不验证证书和hosts
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($params));
        curl_setopt(
            $ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json')
        );
        $result = curl_exec($ch);
        curl_close($ch);
        return $result;
    }
}