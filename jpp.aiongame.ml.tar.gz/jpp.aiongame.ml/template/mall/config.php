<?php
//��ҳBannerͼƬ����
return array(
	'banner1'=>'assets/img/Product/banner1.jpg',
	'banner2'=>'assets/img/Product/banner2.jpg',
	'banner3'=>'assets/img/Product/banner3.jpg',
	'banner4'=>'assets/img/Product/banner4.jpg'
);