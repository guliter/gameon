<?php
$authcode='daishua.cccyun.cc';
$distid='40';

?>